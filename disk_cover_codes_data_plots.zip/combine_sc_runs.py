# -*- coding: utf-8 -*-
"""
combine_sc_runs.py

Created on Thu Dec  3 16:50:15 2020

@author: A Moreno


Combine all npy files (simfiles) in completed_runs folder into one npy file.
Assume simulation parameters are the same in all files!

"""
# Track process time
from timeit import default_timer as timer
start = timer()

from numpy import *
from numpy.random import *
set_printoptions(linewidth=inf)


output_file = 'combined_runs.npy'

# Create list of filenames
simfiles = ("18Nov_MNmin1000_PC2.npy",
            "19Nov_MNmin1000_PC2.npy",
            "21Nov100MNmin_pc2.npy",
            "Nov5_MNmin1000_PC2.npy",
            "Nov11_MN_min1000.npy",
            "Nov13_MNmin1000_1.npy",
            "Nov13_MNmin1000_PC2.npy",
            "Nov13_MNmin1000_PC3.npy",
            "Nov15_MNmin1000_PC3.npy",
            "Nov15_MNmin1000_PC4.npy",
            "Nov16_MNmin1000_PC2.npy",
            "Nov16_MNmin1000_PC4.npy",
            "Nov17_MN1000_PC3.npy",
            "Nov17_MNmin1000_PC2.npy",
            "Nov17_MNmin1000_PC4.npy",
            "Nov18_MNmin1000_PC3.npy",
            "Nov19MNmin1000_PC4.npy",
            "Nov20_MNmin1000_PC4.npy",
            "Nov20MNmin1000_PC2.npy",
            "Nov20MNmin1000_PC3.npy",
            "Nov21_MNmin1000_PC3.npy")
            

# Extract simulation parameters from first file only
simdata = load(simfiles[0], allow_pickle=True)

# Break out simulation parameters
gp_min = simdata[0][0]       # Minimum value for gamma, phi
gp_max = simdata[0][1]       # Maximum value for gamma, phi
a = simdata[0][2]            # Fixed set area
MN_step = simdata[0][3]      # Step value for M, N
MN_min = simdata[0][4]       # Minimum value for M, N
nDatasets = simdata[0][5]    # Number of datasets for each M, N configuration

# Compute total number of datasets
allDatasets = nDatasets * len(simfiles)

# Compute other needed sim parameters
MN_max = int(MN_min * gp_max/gp_min)            # Maximum value for M, N
MN_range = arange(MN_min, MN_max+1, MN_step)    # Includes MN_max!
MN_count = len(MN_range)

# Gather simulation parameters to store in output file
sim_params = [gp_min, gp_max, a, MN_step, MN_min, allDatasets]

# Create arrays to hold data from all simulations
ncvPnts_count = empty([MN_count, MN_count, allDatasets], dtype=float)
scvPnts_count = copy(ncvPnts_count)
colPnts_count = copy(ncvPnts_count)
indPnts_count = copy(ncvPnts_count)
ncvSets_count = copy(ncvPnts_count)
scvSets_count = copy(ncvPnts_count)
colSets_count = copy(ncvPnts_count)
rdnSets_count = copy(ncvPnts_count)
indSets_count = copy(ncvPnts_count)
isl_count = copy(ncvPnts_count)
IslPnts_count = copy(ncvPnts_count)
IslSets_count = copy(ncvPnts_count)
sd_isl_Pnts = copy(ncvPnts_count)
sd_isl_Sets = copy(ncvPnts_count)

print(f'\nOutput array dimensions are {ncvPnts_count.shape}\n\n')


# Initialize indices for array data
i1 = 0
i2 = nDatasets

for simfile in simfiles:
    # Extract data from this simulation file
    print(f'Extracting {simfile}...')
    simdata = load(simfile, allow_pickle=True)
    
    # Append extracted data into corresponding arrays
    ncvPnts_count[:,:,i1:i2] = simdata[1]
    scvPnts_count[:,:,i1:i2] = simdata[2]
    colPnts_count[:,:,i1:i2] = simdata[3]
    indPnts_count[:,:,i1:i2] = simdata[4]
    ncvSets_count[:,:,i1:i2] = simdata[5]
    scvSets_count[:,:,i1:i2] = simdata[6]
    colSets_count[:,:,i1:i2] = simdata[7]
    rdnSets_count[:,:,i1:i2] = simdata[8]
    indSets_count[:,:,i1:i2] = simdata[9]
    isl_count[:,:,i1:i2] = simdata[10]
    IslPnts_count[:,:,i1:i2] = simdata[11]
    IslSets_count[:,:,i1:i2] = simdata[12]
    sd_isl_Pnts[:,:,i1:i2] = simdata[13]
    sd_isl_Sets[:,:,i1:i2] = simdata[14]
    
    # Update array data indices
    i1 += nDatasets
    i2 += nDatasets
    
#
# Data from all simulations now combined - save it!
#

save(output_file,[sim_params, ncvPnts_count, scvPnts_count, colPnts_count, \
                indPnts_count, ncvSets_count, scvSets_count, colSets_count, \
                rdnSets_count, indSets_count, isl_count, \
                IslPnts_count, IslSets_count, sd_isl_Pnts, sd_isl_Sets])
    
print(f'\n\nComplete!  output file is \'{output_file}\'\n')    

# End time tracking...
end = timer()
print(f'\nElapsed time (seconds): {end - start}\n\n')    # Time in seconds