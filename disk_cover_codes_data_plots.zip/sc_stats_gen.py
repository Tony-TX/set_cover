'''
Set Cover Statistics Generation
by C. Thron, with A. Moreno


1) Generate a large number of random datasets based on specified
   simulation parameters.

2) Do set cover analysis for each data set. Includes pre-processing
   to determine all dataset point/set types, and identification of
   islands in dataset.  (Process to determine minimal set cover for 
   each island is still to be developed.)
                          
3) Save simulation parameters and aggregate dataset statistics in a single
   '.npy' format file for further processing and analysis.                           
'''

# Track process time

from timeit import default_timer as timer
start = timer()

from numpy import *
from numpy.random import *
set_printoptions(linewidth=inf)




def getRandDataset(M=200, N=100, r=0.15, A=1.0, init_seed=None):

    '''
    Create a dataset of M random x-y points grouped into a collection of 
    N circular sets with random x-y centers. Data space is a unit square
    with lower left corner at the origin, unless 0 < A < 1.0 is specified. 
    
        NOTE:  For all random points, 0 <= x < sqrt(A) and 0 <= y < Sqrt(A).
    
    Grouping is done via a 2-D incidence matrix with size M x N.  Each row 
    represents one point, and each column represents one set.  The value
    of each point-set incidence is:
        1 - if point is within the corresponding set
        0 - if point not within the corresponding set

    The dataset generation sequence is as follows:
        
        1. Generate M random x-y points and N random x-y set centers.
        2. Using these generated points, determine the value (1 or 0) for
           each point-set incidence.
        3. Once every point-set incidence is determined, remove all uncovered
           points (rows with all zeros) and empty sets (columns with all zeros)
           from the incidence matrix.  Save x-y values for all removed
           points and sets.
        
        NOTE: If there are uncovered points or empty sets, returned
              incidence matrix will be smaller than M x N!
    '''
    
    # For repeatability, use provided seed (default is 'none')
    seed(init_seed)

    # Generate random data
    rand_pnts = sqrt(A) * ranf([M, 2])    # x-y data points
    rand_sets = sqrt(A) * ranf([N, 2])      # x-y circle center points

    # Initialize incidence matrix
    IMx = zeros([M, N])    # set all point-set incidences to 0

    # Identify which points fall within each set
    for i in range(M):
        for j in range(N):
            if r > sum((rand_sets[j] - rand_pnts[i])**2)**(1/2):
                # point_i is inside circle_j !
                IMx[i, j] = 1    # change point-set incidence to 1

    # Find set sizes (columns sums of incidence matrix
    set_sizes = IMx[...].sum(axis=0)

    # Remove empty sets (columns w/sum=0) from incidence matrix
    IMx = IMx[ : , set_sizes > 0]
    
    # Identify/save empty and non-empty sets (x-y centers)
    notnull_sets  = rand_sets[set_sizes > 0]
    null_sets = rand_sets[set_sizes == 0]
    
    # Remove 0-sum values from set sizes (to match saved non-empty sets!)
    set_sizes = set_sizes[set_sizes > 0]

    # Save row sums of point-set incidences (point coverage depths)
    pnt_cdepths = IMx[...].sum(axis=1)
    
    # Identify/save covered and uncovered points (x,y values)
    cov_pnts = rand_pnts[pnt_cdepths > 0, : ]
    unc_pnts  = rand_pnts[pnt_cdepths == 0, : ]
    
    # Remove uncovered points (rows w/sum=0) from incidence matrix
    IMx = IMx[pnt_cdepths > 0, : ]

    # Remove 0-sum values from coverage depths (to match saved covered points!)
    pnt_cdepths = pnt_cdepths[pnt_cdepths > 0]

    # Return incidence matrix empty sets, and uncovered points
    return IMx, unc_pnts, null_sets



def findMinCover(M=200, N=100, r=0.06, A=1.0):
    '''
    Finds minimal set cover for a random dataset.  The random dataset
    is generated via getRandDataset per above input parameters.
    getRandDataset returns:
    	* IMx0 - the random dataset incidence matrix.
        * ncvPnt_vec - points not in any set (these are removed from IMx0)
        * ncvSet_vec - empty sets (these are removed from IMx0)

    Since the non-covered points and null sets are NOT in the incidence
    matrix, they are identified by their [x,y] coordinates.
                          
    All points in the dataset are identified by their original row number
    in IMx0.  Similarly, all sets in the dataset are identified by their
    original column number in IMx0.
    
    Initially, all points/sets in the datasets are considered indeterminate.
    
    Using a IMx (a working copy of IMx0), a pre-processing loop then
    analyzes the random dataset to identify:
    	* single-covered points
    	* collateral points
    	* single-covering sets
    	* redundant sets
    	* collateral sets
        
    As these points and sets are identified, their corresponding rows and
    columns are removed from IMx. When pre-processing is complete, all
    points and sets have been properly identified and grouped, and IMx
    now contains only the indeterminate points and sets.
        
    Next, using IMx_isl (a working copy of IMx) along with the indeterminate
    points and indeterminate set groups (also working copies), all self-
    contained are identified.  As each island is identified, its corresponding
    sets and points are recorded and removed from the indeterminate point/set
    groups and also removed from IMx_isl.  When island processing is complete,
    all indeterminate points/sets have become island points/sets,
    and IMx_isl is empty.
    
	Next, a linear function finds the minimal set cover for each island. 
    This function is still to be developed.
    
    The resulting minimal cover for the dataset includes the single-covering
    sets identified on the first pass of the pre-processing loop and the
    minimal set covers for each island.

    NOTE:    
    Logical mask vectors (vectors with names ending in '_msk') are used to
    flag individual points/sets for identification.
    '''

    # Preserve starting dimensions
    M_start = copy(M)       # Includes non-covered points
    N_start = copy(N)       # Includes non-covering sets

    # Get random dataset
    # Non-covered points and non-covering sets are passed separately
    # since the are not part of the incidence matrix.
    IMx0, ncvPnt_vec, ncvSet_vec = getRandDataset(M,N,r,A)

 	# Preserve info on dataset incidence matrix
    M0, N0 = IMx0.shape
    IMx = copy(IMx0)            
    
    # Create data vectors for grouping of each point/set type.
    # Initially, all points and sets are indeterminate.
    scvPnt_vec = array([])     # single-covered points
    colPnt_vec = array([])     # collateral points
    indPnt_vec = arange(M0)    # indeterminate points                                 
    scvSet_vec = array([])     # single-covering sets
    colSet_vec = array([])     # collateral sets
    rdnSet_vec = array([])     # redundant sets
    indSet_vec = arange(N0)    # indeterminate sets

    
    '''
    Pre-process raw dataset:

        1. Inspect IMx to flag any points that are single covered, and also
           any sets containing those points.
        2. Move the sets flagged in step 1 from indeterminate sets to
           single-covering sets.  Move the points flagged in step 1 from 
           indeterminate points to single-covered points.
        3. Inspect IMx to flag all other points (excluding single-covered
           points) contained in the sets flagged in step 1.    
        4. Move all points flagged in step 3 from indeterminate points to
           collateral points.
        5. Remove IMx point/sets (rows/cols) flagged in steps 1 and 3.
        6. Inspect IMx to flag any sets that were emptied after step 5.
        7. Move the sets flagged in step 6 from indeterminate sets to
           collateral sets.
        8. Remove IMx sets (cols) flagged step 6.
        9. Inspect IMx sets (using pair-wise comparison) to flag any sets
           fully-contained within another set.
        10. Move all sets flagged in step 9 from indeterminate sets to
            redundant sets. 
        11. Remove IMx sets(cols) flagged in step 9.

    Repeat steps 1-11 until there are no changes to IMx.        
    '''

    IMx_oldshape = (0,0)    # Ensure at least one pre-process loop

    while not(IMx.shape == IMx_oldshape):
        IMx_oldshape = IMx.shape

        # Flag points that are single-covered, and the sets containing them.
        scvPnt_msk = sum(IMx[...], axis=1) == 1
        scvSet_msk = sum(IMx[scvPnt_msk, : ], axis=0) > 0
        
        # Re-group flagged sets as single-covering sets.
        scvSet_vec = concatenate((scvSet_vec, indSet_vec[scvSet_msk]))
        indSet_vec = indSet_vec[~scvSet_msk]

        # Add flagged points as single-covered points.
        scvPnt_vec = concatenate((scvPnt_vec, indPnt_vec[scvPnt_msk]))

        # Add all other points in flagged sets to collateral points. 
        colPnt_msk = sum(IMx[:, scvSet_msk], axis = 1) > 0  # select all pnts
        colPnt_msk = colPnt_msk & ~scvPnt_msk    # less scv points 
        colPnt_vec = concatenate((colPnt_vec, indPnt_vec[colPnt_msk]))

        # Remove all flagged points from indeterminate points.
        indPnt_vec = indPnt_vec[~(scvPnt_msk | colPnt_msk)]
        
        # Remove flagged sets/points from incidence matrix
        IMx = IMx[~(scvPnt_msk | colPnt_msk), : ]    # scv and col points
        IMx = IMx[ : , ~scvSet_msk]    # scv sets 

        # Flag any resulting empty sets and regroup them as collateral sets.
        colset_msk = sum(IMx[...], axis=0) == 0
        colSet_vec = concatenate((colSet_vec, indSet_vec[colset_msk]))
        indSet_vec = indSet_vec[~colset_msk]

        # Remove flagged sets from incidence matrix
        IMx = IMx[ : , ~colset_msk]


        # Flag redundant sets in incidence matrix
        nsets = IMx.shape[1]
        rdnset_msk = zeros(nsets, dtype = bool)
        for i in range(nsets - 1):
            # Move to next iset if current iset already flagged
            if rdnset_msk[i] == True:
                continue
            iset = IMx[ : , i]

            for j in range(i + 1, nsets):
                # Move to next jset if current jset already flagged
                if rdnset_msk[j] == True:
                    continue
                jset = IMx[ : , j]

                # Compare iset and jset
                if sum(iset) > sum(jset):
                    # Is jset redundant?  
                    rdnset_msk[j] = all(jset == logical_and(iset, jset))
                else:
                    # Is iset redundant (subset or same as jset)?
                    rdnset_msk[i] = all(iset == logical_and(iset, jset))
                    # if iset is flagged, discontinue jset comparisons
                    if rdnset_msk[i]==True:
                        break


        # Regroup flagged sets as redundant sets
        rdnSet_vec = concatenate((rdnSet_vec, indSet_vec[rdnset_msk]))
        indSet_vec = indSet_vec[~rdnset_msk]
        
        # Remove flagged sets (cols) from incidence matrix
        IMx = IMx[ : , ~rdnset_msk]



    '''
    Identify islands

    Group all indeterminate sets/points into islands to reduce minimal-cover
    processing time.  Use working copies of incidence matrix (IMx_isl) and
    indeterminate points/sets groups.

    To identify an island in incidence matrix:

        1. Flag the first point (row) in IMx_isl.
        2. Inspect IMx_isl to flag all sets that contain any flagged
           point.
        3. Inspect IMx_isl to flag all points contained in any flagged set.
        6. Repeat steps 2 and 3 until no additional points are flagged.
        7. Island identified - save all flagged points as a vector in island
           points list and all flagged sets as a vector in island sets list.
        8. Remove all flagged points from indeterminate points and
           all flagged sets from indeterminate sets.
        9. Remove all flagged points/sets (rows/cols) from incidence matrix.

    Repeat this process until IMx_isl is empty.  At this point, all islands
    are identified.
    '''

    # Preserve current state
    indSets = copy(indSet_vec)  
    indPnts = copy(indPnt_vec)
    IMx_isl = copy(IMx)
    
    # Initialize
    islandPoints = []      # List for vectors of island points 
    islandSets = []        # List for vectors of island sets


    # Identify islands 
    while IMx_isl.shape != (0, 0):  # repeat until IMx_isl empty
        
        # Initialize masks to flag island point/sets
        islSet_msk = zeros(IMx_isl.shape[1], dtype = bool)
        islPnt_msk = zeros(IMx_isl.shape[0], dtype = bool)
        islPnt_msk[0] = True    # flag first point

        while True:
            
            # flag sets that contain any flagged points
            islSet_msk = sum(IMx_isl[islPnt_msk, : ], axis=0) > 0
            
            # flag points contained in any flagged set
            newislPnt_msk = sum(IMx_isl[ : , islSet_msk],axis=1) > 0
            
            # done if additional points flagged
            if all(islPnt_msk == newislPnt_msk):
                break
            else:
                islPnt_msk = newislPnt_msk
            
        # Record flagged points/sets as an island    
        islandPoints += [indPnts[islPnt_msk]]
        islandSets += [indSets[islSet_msk]]
        
        # Remove flagged points/sets
        IMx_isl = IMx_isl[~islPnt_msk, : ][ : , ~islSet_msk]
        indPnts = indPnts[~islPnt_msk]
        indSets = indSets[~islSet_msk]
        

    # Done! Return dataset info...
    #
    # NOTE: All output values are counts (float variables) except
    #       islandPoints and islandSets, which are lists of vectors
    
    return len(ncvPnt_vec), len(scvPnt_vec), len(colPnt_vec), len(indPnt_vec), \
            len(ncvSet_vec), len(scvSet_vec), len(colSet_vec), \
            len(rdnSet_vec), len(indSet_vec), islandPoints, islandSets
            



#### End of function definitions



###############################################################################



#### Begin main
            
            

output_file = input("Name of output file? ")
#nDatasets = int(input("Number of datasets? "))     # per configuration     

# Specify simulation parameters
gp_min = 3         # Minimum value for gamma, phi
gp_max = 12        # Maximum value for gamma, phi
MN_min = 1000      # Minimum value for M, N
# MN_step = 200     # Step value for M, N
MN_step = 500      # Step value for M, N
nDatasets = 5      # Number of datasets for each M, N configuration

# Compute additional simulation parameters
MN_max = int(MN_min * gp_max/gp_min)
a = gp_min / MN_min    # Fixed set area
MN_range = arange(MN_min, MN_max+1, MN_step)    # Includes MN_max!
MN_count = len(MN_range)
 

# Gather simulation parameters to store in output file
sim_params = [gp_min, gp_max, a, MN_step, MN_min, nDatasets]



# Create arrays for all data to be recorded.
ncvPnts_count = empty([MN_count, MN_count, nDatasets], dtype=float)
									   # Non-covered points count
scvPnts_count = copy(ncvPnts_count)    # Single-covered points count
colPnts_count = copy(ncvPnts_count)    # Collateral points count		
indPnts_count = copy(ncvPnts_count)    # Indeterminate points count
ncvSets_count = copy(ncvPnts_count)    # Null sets count
scvSets_count = copy(ncvPnts_count)    # Single-covering sets count
colSets_count = copy(ncvPnts_count)    # Collateral sets count
rdnSets_count = copy(ncvPnts_count)    # Redundant sets count
indSets_count = copy(ncvPnts_count)    # Indeterminate sets count
isl_count = copy(ncvPnts_count)        # Number of islands in dataset
IslPnts_count = copy(ncvPnts_count)    # Number of points in largest island 
IslSets_count = copy(ncvPnts_count)    # Number of sets in largest island 
sd_isl_Pnts = copy(ncvPnts_count)    # Standard deviation of points per island
sd_isl_Sets = copy(ncvPnts_count)    # Standard deviation of sets per island


# Generate data for recording
print(f'\n\nNumber of datasets per M, N configuration: {nDatasets}')

# Select successive number of points M
for i in range(MN_count):
    m = MN_range[i]
    #print(f'\n\nM = {m}\nN = ', end=' ')

    # Select successive number of sets N
    for j in range(MN_count):
        n = MN_range[j]
        #print(f'{n}', end=' ')

        # Calculate 'speedup' parameters
        q = min(m,n)/MN_min
        a1 = a*q
        m1 = int(m/q)
        n1 = int(n/q)
        r1 = sqrt(a1/pi)    # Radius for circle of area a              
        print(f'\nM={m}, M\'={m1}, N={n}, N\'={n1}, k = ', end=' ')
            

        # Generate all datasets for this configuration
        for k in range(nDatasets):
            print(f'{k}', end=' ')

            # Generate next dataset (A = 1.0 by default) and save counts
            ncvPnts_count[i,j,k], scvPnts_count[i,j,k], \
                colPnts_count[i,j,k], indPnts_count[i,j,k], \
                ncvSets_count[i,j,k], scvSets_count[i,j,k], \
                colSets_count[i,j,k], rdnSets_count[i,j,k], \
                    indSets_count[i,j,k], islandPoints, islandSets\
                            = findMinCover(M=m1, N=n1, r=r1)
                            
            # Compute remaining statistics for this dataset           
            isl_count[i,j,k] = len(islandSets)
            
            if isl_count[i,j,k] == 0:
                # No islands, so remaining stats are 0
                IslPnts_count[i,j,k] = 0
                IslSets_count[i,j,k] = 0
                sd_isl_Pnts[i,j,k] = 0.
                sd_isl_Sets[i,j,k] = 0.
            else:
                # At least one island, so compute stats!
                island_pntCounts = [len(i) for i in islandPoints]
                island_setCounts = [len(i) for i in islandSets]
                IslPnts_count[i,j,k] = max(island_pntCounts)
                IslSets_count[i,j,k] = max(island_setCounts)
                sd_isl_Pnts[i,j,k] = std(island_pntCounts)
                sd_isl_Sets[i,j,k] = std(island_setCounts)
 

# All data acquired - save it!
save(output_file,[sim_params, ncvPnts_count, scvPnts_count, colPnts_count, \
                indPnts_count, ncvSets_count, scvSets_count, colSets_count, \
                rdnSets_count, indSets_count, isl_count, \
                IslPnts_count, IslSets_count, sd_isl_Pnts, sd_isl_Sets])

# End time tracking...
end = timer()
print(f'\nElapsed time (seconds): {end - start}\n\n')    # Time in seconds