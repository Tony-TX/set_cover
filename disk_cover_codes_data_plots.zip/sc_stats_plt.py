'''

sc_stats_plt.py  Rev 2

11/10/2020
C. Thron, with A. Moreno


Extracts set cover simulation data from input_file (in 'npy' format),
then prepares it for plotting via imshow. The input_file contains both the
simulation parameters and generated data.
                   
'''


# Track process time
from timeit import default_timer as timer
start = timer()

from numpy import *
from numpy.random import *
set_printoptions(linewidth=inf)

#%matplotlib inline
from matplotlib.pyplot import *
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

close('all')




def showData():

    '''
    Print and show each array of calculated statistics
    NOTE:  All data arrays are global!
    '''
    
    showPlot('Proportion of Non-Covered Points', p_ncvPnts)
    showPlot('Proportion of Non-Covering Sets', p_ncvSets)
    showPlot('Proportion of Single-Covered Points', p_scvPnts)
    showPlot('Proportion of Single-Covering Sets', p_scvSets)
    showPlot('Proportion of Collateral Points', p_colPnts)
    showPlot('Proportion of Collateral Sets', p_colSets)
    showPlot('Proportion of Redundant Sets', p_rdnSets)
    showPlot('Proportion of Points Covered by Indeterminate Sets', p_indPnts)
    showPlot('Proportion of Indeterminate Sets', p_indSets)
    showPlot('Proportion of Points in Largest Island', p_IslPnts)
    showPlot('Proportion of Indeterminate Points in Largest Island', p_Isl_indPnts)
    showPlot('Proportion of Sets in Largest Island', p_IslSets)
    showPlot('Proportion of Indeterminate Sets in Largest Island', p_Isl_indSets)
    showPlot('Mean Proportion of Points per Island', mp_isl_Pnts)
    showPlot('Mean Proportion of Sets per Island', mp_isl_Sets)
    showPlot('Mean Proportion of Indeterminate Points/Sets per Island', mp_isl_indPntsSets)
    showPlot('Standard Deviation of Proportion of Points per Island', sdp_isl_Pnts)
    showPlot('Standard Deviation of Proportion of Sets per Island', sdp_isl_Sets)
    showPlot('Standard Deviation of Proportion of Indeterminate Points per Island', sdp_isl_indPnts)
    showPlot('Standard Deviation of Proportion of Indeterminate Sets per Island', sdp_isl_indSets)

    return


        
def showPlot(dtitle, data):

    '''
    Plot the given data array.
    NOTE: All plot parameters are global!
    '''

    fig, ax = subplots(1, 1, figsize=(8,14))
    img = ax.imshow(data, interpolation='spline36', cmap='jet', origin='lower',
           extent=(gp_min,gp_max,gp_min,gp_max))
    # fig.colorbar(img, fraction=0.0275, pad=0.04)
    fig.colorbar(img, fraction=0.04, pad=0.04)
    title('\n\n' + dtitle, fontsize=16, fontweight='bold')        
    
    
    xlabel(x_label, fontsize=16, fontweight='bold')
    ylabel(y_label, fontsize=16, fontweight='bold')
    
    show()
    #print('========================================================')
    
    return



#### End of function definitions



###############################################################################



#### Begin main
            
            
'''            
1. Extract simulation data from input file.
'''

# Read sim data file
# sim_file = 'Nov13_MNmin1000.npy'
simdata_file = input("Name of input file? ")
simdata = load(simdata_file, allow_pickle=True)

# Extract simulation parameters
gp_min = simdata[0][0]       # Minimum value for gamma, phi
gp_max = simdata[0][1]       # Maximum value for gamma, phi
a = simdata[0][2]            # Fixed set area
MN_step = simdata[0][3]      # Step value for M, N
MN_min = simdata[0][4]       # Minimum value for M, N
nDatasets = simdata[0][5]    # Number of datasets for each M, N configuration

# Compute other needed sim parameters
MN_max = int(MN_min * gp_max/gp_min)            # Maximum value for M, N
MN_range = arange(MN_min, MN_max+1, MN_step)    # Includes MN_max!
MN_count = len(MN_range)

# Calculate 'speedup' parameters
N_arr = tile(MN_range,(len(MN_range),1))
M_arr = N_arr.T
q_arr = minimum(M_arr,N_arr)/MN_min
m1_arr = (M_arr/q_arr).astype(int)
n1_arr = (N_arr/q_arr).astype(int)


# Extract each simulation data array
ncvPnts_count = simdata[1]
scvPnts_count = simdata[2]
colPnts_count = simdata[3]
indPnts_count = simdata[4]
ncvSets_count = simdata[5]
scvSets_count = simdata[6]
colSets_count = simdata[7]
rdnSets_count = simdata[8]
indSets_count = simdata[9]
isl_count = simdata[10]
IslPnts_count = simdata[11]
IslSets_count = simdata[12]
sd_isl_Pnts = simdata[13]
sd_isl_Sets = simdata[14]


print('Simulation data file: ',simdata_file)

print(f'\nExtracted Simulation Parameters')
print(f'-------------------------------')
print(f'gp_min = {gp_min}, gp_max = {gp_max}')
print(f'a = {a}')
print(f'MN_step = {MN_step}, MN_min = {MN_min}')
print(f'nDatasets = {nDatasets}')

print(f'\nCalculated Simulation Parameters')
print(f'--------------------------------')
print(f'MN_max = {MN_max}')
print(f'MN_range = {MN_range}')
print(f'MN_count = {MN_count}')

print(f'\nExtracted Simulation Data')
print(f'-------------------------')
print(f'ncvPnts_count{ncvPnts_count.shape} - number of non-covered points')
print(f'scvPnts_count{scvPnts_count.shape} - number of single-covered points')
print(f'colPnts_count{colPnts_count.shape} - number of collateral points')
print(f'indPnts_count{indPnts_count.shape} - number of indeterminate points')

print(f'\nncvSets_count{ncvSets_count.shape} - number of non-covering sets')
print(f'scvSets_count{scvSets_count.shape} - number of single-covering sets')
print(f'colSets_count{colSets_count.shape} - number of collateral sets')
print(f'rdnSets_count{rdnSets_count.shape} - number of redundant sets')
print(f'indSets_count{indSets_count.shape} - number of indeterminate sets')
            
print(f'\nisl_count{isl_count.shape} - number of islands')
print(f'IslPnts_count{IslPnts_count.shape} - number of points in largest island')
print(f'IslSets_count{IslSets_count.shape} - number of sets in largest island')
print(f'sd_isl_Pnts{sd_isl_Pnts.shape} - standard deviation of number of points per island')
print(f'sd_isl_Sets{sd_isl_Sets.shape} - standard deviation of number of sets per island') 


'''
2. Prepare simulation data for plotting.

Every MxN combination has 'nDataset' values per simulation data type.
Compute the mean of each group of 'nDataset' values.
'''


# Proportion of non-covered points
p_ncvPnts = ncvPnts_count.sum(axis=2)/m1_arr/nDatasets

# Proportion of non-covered sets
p_ncvSets = ncvSets_count.sum(axis=2)/n1_arr/nDatasets

# Proportion of single-covered points
p_scvPnts = scvPnts_count.sum(axis=2)/m1_arr/nDatasets

# Proportion of single-covering sets
p_scvSets = scvSets_count.sum(axis=2)/n1_arr/nDatasets

# Proportion of collateral points
p_colPnts = colPnts_count.sum(axis=2)/m1_arr/nDatasets

# Proportion of collateral sets
p_colSets = colSets_count.sum(axis=2)/n1_arr/nDatasets

# Proportion of redundant sets
p_rdnSets = rdnSets_count.sum(axis=2)/n1_arr/nDatasets

# Proportion of points covered by indeterminate sets
p_indPnts = indPnts_count.sum(axis=2)/m1_arr/nDatasets

# Proportion of indeterminate sets
p_indSets = indSets_count.sum(axis=2)/n1_arr/nDatasets

# Proportion of points in largest island
p_IslPnts = IslPnts_count.sum(axis=2)/m1_arr/nDatasets

# Proportion of indeterminate points in largest island
p_Isl_indPnts = p_IslPnts/p_indPnts

# Proportion of sets in largest island
p_IslSets = IslSets_count.sum(axis=2)/n1_arr/nDatasets

# Proportion of indeterminate sets in largest island
p_Isl_indSets = p_IslSets/p_indSets

# Mean proportion of points per island
mp_isl_Pnts = (indPnts_count+(indPnts_count ==0))  / (isl_count+(isl_count==0))
mp_isl_Pnts = mp_isl_Pnts.sum(axis=2) / nDatasets / m1_arr

# Mean proportion of sets per island
mp_isl_Sets = (indSets_count+(indSets_count ==0))  / (isl_count+(isl_count==0))
mp_isl_Sets = mp_isl_Sets.sum(axis=2) / nDatasets / n1_arr

# Mean proportion of indeterminate points/sets per island
mp_isl_indPntsSets = sum(1 / maximum(1,isl_count),axis=2)/nDatasets

# Standard deviation of proportion of points per island
#(equal to the std dev of the number of points/island divided by the total number of points)
sdp_isl_Pnts = sd_isl_Pnts.sum(axis=2)/nDatasets / m1_arr

# Standard deviation of proportion of sets per island
#(equal to the standard deviation of the number of sets per island divided by the total number of sets)
sdp_isl_Sets = sd_isl_Sets.sum(axis=2)/nDatasets / n1_arr

# Standard deviation of proportion of indeterminate points per island
# (equal to the standard deviation of the number of points per island divided by the total number of indeterminate points)
sdp_isl_indPnts = sum(sd_isl_Pnts/(indPnts_count+(indPnts_count==0)),axis=2)/nDatasets

# Standard deviation of proportion of indeterminate sets per island
# (equal to the standard deviation of the number of sets per island divided by the total number of indeterminate sets)
sdp_isl_indSets = sum(sd_isl_Sets/(indSets_count+(indSets_count==0)),axis=2)/nDatasets


'''
All simulation data prepared - plot it!

NOTE:  For simplicity, all x-y label/tick params and data arrays are global.
'''

# First, initialize for all plotting
x_label = r'$\phi \quad (\frac{Na}{A})$'
y_label = r'$\gamma \quad (\frac{Ma}{A})$'

# Now plot...
showData()

# End time tracking...
end = timer()
print(f'\nElapsed time (seconds): {end - start}\n\n')    # Time in seconds