'''

sc_stats_thyplt.py

11/6/2020
C. Thron, with A. Moreno


Calculate/plot theoretical statistical values based on parameters defined
.
                        
'''


# simdata_file = input("Name of input file? ")


# Track process time
from timeit import default_timer as timer
start = timer()

from numpy import *
from numpy.random import *
set_printoptions(linewidth=inf)

#%matplotlib inline
from matplotlib.pyplot import *
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

close('all')




def showData():

    '''
    Plot and show each theoretical statistic.
        
    NOTE:  All data arrays are global!
    '''
    
    showPlot('Theoretical Proportion of Non-Covered Points',
             t_ncvPnts_prop, maxC=0.055)
        
    showPlot('Theoretical Proportion of Single-Covered Points',
             t_scvPnts_prop, maxC=0.45)
        
    showPlot('Theoretical Proportion of Points Covered by Indeterminate Sets',
             t_indPnts_prop, minC=0.15, maxC=0.85)
        
    showPlot('Theoretical Proportion of Non-Covering Sets',
             t_ncvSets_prop, maxC=0.055)
        
    showPlot('Theoretical Proportion of Single-Covering Sets',
             t_scvSets_prop, maxC=0.425)
        
    showPlot('Theoretical Proportion of Indeterminate Sets',
             t_indSets_prop, minC=0.1, maxC=0.7)

    return



        
def showPlot(dtitle, data, minC=None, maxC=None):
    '''
    Plot the given data array.
    NOTE: All plot parameters are global!
    '''

    fig, ax = subplots(1, 1, figsize=(8,14))
    
    img = ax.imshow(data, interpolation='spline36', cmap='jet', origin='lower',
            vmin=minC, vmax=maxC, extent=(gp_min,gp_max,gp_min,gp_max))
    
    # fig.colorbar(img, fraction=0.0275, pad=0.04)
    fig.colorbar(img, fraction=0.04, pad=0.04)
    
    title('\n\n' + dtitle, fontsize=16, fontweight='bold')        
        
    xlabel(x_label, fontsize=16, fontweight='bold')
    ylabel(y_label, fontsize=16, fontweight='bold')
    
    show()
    
    return



#### End of function definitions



###############################################################################



#### Begin main
            
            
'''
1. Define parameters for theoretical values.
'''

gp_min = 3           # Minimum value for gamma, phi
gp_max = 12          # Maximum value for gamma, phi
MN_step = 200        # Step value for M, N
MN_min = 1000        # Minimum value for M, N
a = gp_min/MN_min    # area of circle-set

MN_max = int(MN_min * gp_max/gp_min)            # Maximum value for M, N
MN_range = arange(MN_min, MN_max+1, MN_step)    # Includes MN_max!

print(f'\nParameters for theoretical calculations')
print(f'gp_min = {gp_min}')
print(f'gp_max = {gp_max}')
print(f'a = {a}')
print(f'MN_range = {MN_range}')

# Form M, N, phi and gamma arrays for computations
N_arr = tile(MN_range,(len(MN_range),1))
M_arr = N_arr.T
phi_arr = N_arr * a     
gamma_arr = M_arr * a

# Mprop_delta = 1 / M_arr
# Nprop_delta = 1 / N_arr
Mprop_delta = 0.0
Nprop_delta = 0.0


'''
2. Calculate theoretical values.
'''

t_ncvPnts_prop = e**(-phi_arr) + Mprop_delta
t_scvPnts_prop = phi_arr * e**(-phi_arr) + Mprop_delta
t_indPnts_prop = 1 - t_ncvPnts_prop - t_scvPnts_prop + Mprop_delta

t_ncvSets_prop = e**(-gamma_arr) + Nprop_delta
t_scvSets_prop = 1 - e**(-gamma_arr * phi_arr * e**(-phi_arr)) + Nprop_delta
t_indSets_prop = 1 - t_scvSets_prop - t_ncvSets_prop + Nprop_delta



'''
3. All simulation data prepared - plot it!

NOTE:  For simplicity, x-y labels and data arrays are global.
'''

# First, initialize for all plotting
x_label = r'$\phi \quad (\frac{Na}{A})$'
y_label = r'$\gamma \quad (\frac{Ma}{A})$'

# Now plot...
showData()

# End time tracking...
end = timer()
print(f'\nElapsed time (seconds): {end - start}\n\n')    # Time in seconds